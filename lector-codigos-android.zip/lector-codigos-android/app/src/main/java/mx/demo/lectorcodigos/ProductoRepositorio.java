package mx.demo.lectorcodigos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Catálogo de productos (CSV: codigo,nombre,precio — acepta coma o punto y coma). */
public class ProductoRepositorio {

    public enum Tipo {
        EXACTA("✔ Exacta"),
        SIN_MAYUSCULAS("≈ Igual ignorando mayúsculas/minúsculas"),
        PARECIDA("? Parecida (posible error de lectura)");

        public final String etiqueta;

        Tipo(String etiqueta) {
            this.etiqueta = etiqueta;
        }
    }

    public static class Coincidencia {
        public final Tipo tipo;
        public final Producto producto;

        Coincidencia(Tipo tipo, Producto producto) {
            this.tipo = tipo;
            this.producto = producto;
        }
    }

    private static final int DISTANCIA_MAXIMA = 1;
    private static final int LONGITUD_MINIMA_PARECIDA = 5;

    private final List<Producto> productos = new ArrayList<>();

    public ProductoRepositorio() {
    }

    public ProductoRepositorio(InputStream in) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                linea = linea.replace("\uFEFF", "").trim();
                if (linea.isEmpty() || linea.toLowerCase().startsWith("codigo")) continue;
                String sep = linea.contains(";") ? ";" : ",";
                String[] p = linea.split(sep, 3);
                if (p.length < 2 || p[0].trim().isEmpty()) continue;
                double precio = 0;
                if (p.length == 3) {
                    try {
                        precio = Double.parseDouble(p[2].trim().replace(',', '.'));
                    } catch (NumberFormatException ignorada) {
                        // precio inválido: queda en 0
                    }
                }
                productos.add(new Producto(p[0].trim(), p[1].trim(), precio));
            }
        }
    }

    public int total() {
        return productos.size();
    }

    /** Busca: exacta, luego ignorando mayúsculas, luego parecida (1 carácter de diferencia). */
    public List<Coincidencia> buscar(String codigo) {
        List<Coincidencia> res = new ArrayList<>();

        for (Producto p : productos) {
            if (p.codigo.equals(codigo)) res.add(new Coincidencia(Tipo.EXACTA, p));
        }
        if (!res.isEmpty()) return res;

        for (Producto p : productos) {
            if (p.codigo.equalsIgnoreCase(codigo)) res.add(new Coincidencia(Tipo.SIN_MAYUSCULAS, p));
        }
        if (!res.isEmpty()) return res;

        if (codigo.length() >= LONGITUD_MINIMA_PARECIDA) {
            String c = codigo.toLowerCase();
            for (Producto p : productos) {
                if (distancia(c, p.codigo.toLowerCase()) <= DISTANCIA_MAXIMA) {
                    res.add(new Coincidencia(Tipo.PARECIDA, p));
                }
            }
        }
        return res;
    }

    private static int distancia(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int costo = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + costo);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
