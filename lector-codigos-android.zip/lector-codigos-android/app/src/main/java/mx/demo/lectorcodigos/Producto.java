package mx.demo.lectorcodigos;

import java.util.Locale;

public class Producto {
    public final String codigo;
    public final String nombre;
    public final double precio;

    public Producto(String codigo, String nombre, double precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return String.format(Locale.US, "%s | $%.2f", nombre, precio);
    }
}
